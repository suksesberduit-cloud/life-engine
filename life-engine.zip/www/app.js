
const $=s=>document.querySelector(s);
let S={entries:[],exp:null};
const DB=()=>new Promise((res,rej)=>{const r=indexedDB.open('lie',1);r.onupgradeneeded=()=>r.result.createObjectStore('kv');r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
async function dbGet(){const d=await DB();return new Promise(res=>{const q=d.transaction('kv').objectStore('kv').get('state');q.onsuccess=()=>res(q.result);q.onerror=()=>res(null)})}
async function dbSet(v){const d=await DB();return new Promise((res,rej)=>{const t=d.transaction('kv','readwrite');t.objectStore('kv').put(v,'state');t.oncomplete=res;t.onerror=()=>rej(t.error)})}
let saveErr=false;
const save=()=>{dbSet(JSON.parse(JSON.stringify(S))).then(()=>{saveErr=false}).catch(()=>{saveErr=true;alert('Gagal menyimpan ke penyimpanan lokal. Ekspor data sekarang sebagai cadangan.')})};
const esc=t=>String(t).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const I={
 home:'<path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
 book:'<path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3zM5 17a3 3 0 0 1 3-3h11"/>',
 chk:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-5-5M8 11l2 2 4-4"/>',
 exp:'<path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 2 3h10a2 2 0 0 0 2-3l-5-9V3"/>',
 evo:'<path d="M3 20h18M6 16l4-5 4 3 5-8"/>',
 mic:'<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>'};
const ic=(k)=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${I[k]}</svg>`;
const TABS=[['home','Beranda'],['book','Diary'],['chk','Checker'],['exp','Eksperimen'],['evo','Evolusi']];
let tab=0;
function go(i){tab=i;
 $('#nv').innerHTML=TABS.map((t,j)=>`<button onclick="go(${j})" ${j==i?'aria-current="true"':''}>${ic(t[0])}${t[1]}</button>`).join('');
 [home,diary,checker,exper,evo][i]();window.scrollTo(0,0)}
const dayKey=d=>new Date(d).toLocaleDateString('sv-SE');
function home(){
 const today=S.entries.filter(e=>dayKey(e.t)==dayKey(Date.now())).length;
 const on=navigator.onLine;
 $('#v').innerHTML=`<p class="mut">${new Date().toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long',year:'numeric'})}</p>
 <h1>Selamat datang</h1><p class="mut">Catat pengalaman. Periksa kenyataan. Pahami pola. Uji perbaikan. Evaluasi bukti.</p>
 ${focusCard()}${ruleCard()}
 <div class="chips"><span class="chip on">Penyimpanan lokal</span><span class="chip ${on?'on':'wr'}">${on?'Online':'Offline'}</span><span class="chip wr">AI: belum dikonfigurasi</span></div>
 <div class="card"><h2>Hari ini</h2><p>${today?today+' catatan tersimpan.':'Belum ada catatan hari ini. Tidak apa-apa.'}</p></div>
 <div class="card"><h2>Eksperimen berjalan</h2><p>${S.exp?esc(S.exp.aksi)+' — hari ke-'+(S.exp.log.length+1)+' dari '+S.exp.hari:'Belum ada. Buka tab Eksperimen untuk memulai satu.'}</p></div>
 <div class="card"><h2>Alat pertumbuhan</h2><div class="row"><button class="btn g" onclick="sub(0)">Kompas nilai</button><button class="btn g" onclick="sub(1)">Tinjauan mingguan</button></div><div class="row" style="margin-top:8px"><button class="btn g" onclick="sub(2)">Buku aturan</button><button class="btn g" onclick="sub(3)">Decision Lab</button></div></div><p class="note">Data tersimpan hanya di perangkat ini. Ekspor berkala sebagai cadangan; data hilang jika aplikasi dihapus atau data browser dibersihkan.</p>`}
function focusCard(){const k=dayKey(Date.now());const f=S.focus&&S.focus.day==k?S.focus:null;const last=S.entries.find(e=>e.c);const en=(S.en||{})[k];let top;
 if(f){top=`<p style="font:600 20px/1.35 Newsreader,Georgia,serif;margin:6px 0 12px">${esc(f.text)}</p>`+(f.done==null?`<div class="row"><button class="btn" onclick="markF(true)">Sudah dilakukan</button><button class="btn g" onclick="markF(false)">Belum</button></div>`:`<p class="mut">${f.done?'Tercatat: dilakukan.':'Tercatat: belum dilakukan. Itu data, bukan kegagalan.'} <button class="del" onclick="resetF()">Ubah</button></p>`)}
 else top=`<input id="fi" aria-label="Tindakan kecil hari ini" placeholder="Contoh: mulai tugas 5 menit setelah istirahat" value="${last?esc(last.c):''}">${S.vals&&S.vals.length?`<select id="fv" aria-label="Untuk nilai" style="margin-top:8px"><option value="">Tanpa nilai</option>${S.vals.map(v=>`<option value="${v.id}">${esc(v.t)}</option>`).join('')}</select>`:''}<div class="row" style="margin-top:8px"><button class="btn" onclick="setF()">Tetapkan</button></div>${last?'<p class="hint" style="margin-top:6px">Terisi dari kolom perbaiki di catatan terakhirmu. Ubah bila perlu.</p>':'<p class="hint" style="margin-top:6px">Pilih satu hal kecil yang realistis. Nanti malam kamu cukup menjawab: sudah atau belum.</p>'}`;
 return `<div class="hero"><h2>Satu tindakan kecil hari ini</h2>${top}<p class="sub">Energi saat ini (opsional)</p><div class="row">${[1,2,3,4,5].map(n=>`<button class="en ${en==n?'sel':''}" aria-label="Energi ${n} dari 5" onclick="setEn(${n})">${n}</button>`).join('')}</div>
 <div class="row" style="margin-top:14px"><button class="btn g" onclick="go(1);setTimeout(()=>{document.getElementById('f0').focus();mic(0)},80)">${ic('mic')}Catat suara</button><button class="btn g" onclick="go(1);setTimeout(()=>document.getElementById('f0').focus(),50)">Tulis</button></div></div>`}
function setF(){const t=$('#fi').value.trim();if(!t)return;S.focus={day:dayKey(Date.now()),text:t,done:null,v:+(($("#fv")||{}).value||0)};save();home()}
function markF(v){S.focus.done=v;S.fl=(S.fl||[]).filter(x=>x.day!=S.focus.day);S.fl.push({day:S.focus.day,text:S.focus.text,done:v,v:S.focus.v});save();home()}
function resetF(){S.fl=(S.fl||[]).filter(x=>x.day!=S.focus.day);S.focus=null;save();home()}
function setEn(n){S.en=S.en||{};S.en[dayKey(Date.now())]=n;save();home()}
const FIELDS=[['Apa yang benar-benar terjadi?','Ceritakan pengalaman hari ini tanpa buru-buru menghakimi diri.','Hari ini aku mengalami...'],
['Apa yang kupelajari?','Apa yang kusadari tentang fakta, asumsi, emosi, atau pola yang mungkin berulang?','Hal yang kupelajari hari ini...'],
['Apa yang akan kuperbaiki?','Satu tindakan kecil yang realistis untuk langkah berikutnya.','Satu tindakan kecil berikutnya...']];
function field(i){const f=FIELDS[i];return `<label for="f${i}">${f[0]}</label><p class="hint">${f[1]}</p>
 <div class="fw"><textarea id="f${i}" placeholder="${f[2]}"></textarea><button class="mic" id="m${i}" aria-label="Dikte untuk kolom: ${f[0]}" onclick="mic(${i})">${ic('mic')}</button></div><div class="st" id="s${i}">Siap</div>`}
function diary(){
 $('#v').innerHTML=`<h1>Diary</h1>${[0,1,2].map(field).join('')}
 <div class="row" style="margin-top:14px"><button class="btn" onclick="saveEntry()">Simpan jurnal</button><button class="btn g" onclick="exportJ()">Ekspor</button><button class="btn g" onclick="$('#imp').click()">Impor</button></div><input id="imp" type="file" accept="application/json" hidden onchange="importJ(this.files[0])"><div class="st" id="sv"></div>
 <h2 style="margin-top:22px">Riwayat</h2><input id="q" placeholder="Cari jurnal" oninput="hist()"><div class="card" id="h" style="margin-top:10px"></div>`;hist()}
function saveEntry(){const v=[0,1,2].map(i=>$('#f'+i).value.trim());
 if(!v.some(Boolean)){$('#sv').textContent='Isi minimal satu kolom.';return}
 S.entries.unshift({id:Date.now(),t:Date.now(),a:v[0],b:v[1],c:v[2]});save();
 [0,1,2].forEach(i=>$('#f'+i).value='');$('#sv').textContent='Tersimpan di perangkat ini.';hist()}
function hist(){const q=($('#q')?.value||'').toLowerCase();
 const L=S.entries.filter(e=>(e.a+e.b+e.c).toLowerCase().includes(q));
 $('#h').innerHTML=L.length?L.map(e=>`<div class="ent"><span class="mut">${new Date(e.t).toLocaleString('id-ID',{dateStyle:'medium',timeStyle:'short'})}</span>
 ${[e.a,e.b,e.c].map((x,i)=>x?`<p><b>${['Terjadi','Dipelajari','Perbaiki'][i]}:</b> ${esc(x)}</p>`:'').join('')}
 <button class="del" onclick="delE(${e.id})">Hapus</button></div>`).join(''):'<p class="mut">Belum ada jurnal yang cocok.</p>'}
function delE(id){if(confirm('Hapus jurnal ini?')){S.entries=S.entries.filter(e=>e.id!=id);save();hist()}}
function exportJ(){const b=new Blob([JSON.stringify(S.entries,null,2)],{type:'application/json'});
 const u=URL.createObjectURL(b);const a=document.createElement('a');a.href=u;a.download='jurnal.json';a.click();
 $('#sv').textContent='Jika unduhan tidak muncul di preview ini, itu normal; di APK/PWA akan berfungsi.'}
let rec=null,recI=-1;
function mic(i){const NP=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.SpeechRecognition;if(NP){micNative(i,NP);return}const SR=window.SpeechRecognition||window.webkitSpeechRecognition;const st=$('#s'+i);
 if(!SR){st.textContent='Dikte tidak didukung di browser ini. Ketik manual, atau pakai ikon mikrofon di papan ketik Android.';return}
 if(rec){rec.stop();return}
 const ta=$('#f'+i);const base=ta.value;let fin='';
 rec=new SR();recI=i;rec.lang='id-ID';rec.interimResults=true;rec.continuous=true;
 rec.onstart=()=>{$('#m'+i).classList.add('live');st.textContent='Mendengarkan... ketuk lagi untuk berhenti'};
 rec.onresult=ev=>{let it='';for(let k=ev.resultIndex;k<ev.results.length;k++){const r=ev.results[k];if(r.isFinal)fin+=r[0].transcript+' ';else it+=r[0].transcript}
  ta.value=(base?base.replace(/\s*$/,' '):'')+fin+it;st.textContent='Mengubah suara menjadi teks...'};
 rec.onerror=e=>{st.textContent=e.error=='not-allowed'||e.error=='service-not-allowed'?'Izin mikrofon ditolak atau diblokir di sini.':e.error=='network'?'Koneksi diperlukan untuk dikte.':'Terjadi kesalahan: '+e.error};
 rec.onend=()=>{$('#m'+i)?.classList.remove('live');if(/Mendengarkan|Mengubah/.test(st.textContent))st.textContent='Selesai. Periksa dan koreksi teks bila perlu.';rec=null};
 try{rec.start()}catch(e){st.textContent='Tidak bisa memulai dikte.';rec=null}}
const RULES=[[/(sepertinya|kayaknya|mungkin|pasti|jelas)/i,'i'],[/(selalu|tidak pernah|semua|sama sekali)/i,'i'],[/(tidak pandai|bodoh|gagal total|payah|tidak mampu)/i,'i'],[/(merasa|sedih|cemas|kesal|takut|senang|lelah|capek)/i,'n']];
function checker(){
 $('#v').innerHTML=`<h1>Checker</h1><p class="mut">Pemeriksaan lokal berbasis kata kunci sederhana. Ini bukan AI dan bukan vonis.</p>
 <label for="ck">Tulis satu pengalaman</label><div class="fw"><textarea id="ck" placeholder="Usaha hari ini sepi. Sepertinya aku tidak pandai mengelola bisnis."></textarea></div>
 <button class="btn" style="margin-top:10px" onclick="runCk()">Periksa</button><div id="ckr"></div>`}
function runCk(){const t=$('#ck').value.trim();if(!t)return;
 const ss=t.split(/(?<=[.!?])\s+/).filter(Boolean);let gen=false;
 const rows=ss.map(s=>{let k='f';for(const [re,x] of RULES)if(re.test(s)){k=x;break}
  if(/(selalu|tidak pernah|semua|tidak pandai|gagal total)/i.test(s))gen=true;
  return `<p><span class="tag t-${k}">${{f:'Fakta (kandidat)',i:'Interpretasi / asumsi',n:'Emosi'}[k]}</span>${esc(s)}</p>`}).join('');
 $('#ckr').innerHTML=`<div class="card" style="margin-top:12px"><h2>Pemisahan</h2>${rows}</div>
 <div class="card"><h2>Penjelasan alternatif</h2><p>Faktor di luar kendali yang belum diperiksa: cuaca, daya beli, persaingan, stok, harga, musim.</p></div>
 <div class="card"><h2>Pertanyaan penguji</h2><p>${gen?'Ini mungkin mengandung generalisasi berlebihan. Apakah ada bukti yang mendukung atau membantahnya?':'Bukti apa yang bisa kamu cek untuk membedakan fakta dari dugaan?'} Apakah hari sepi serupa terjadi minggu lalu?</p>
 <p><b>Tingkat keyakinan:</b> dugaan awal (satu kejadian belum cukup untuk kesimpulan).</p>
 <button class="btn g" onclick="go(3)">Jadikan eksperimen</button></div>`}
function exper(){
 if(S.exp){const e=S.exp;
  $('#v').innerHTML=`<h1>Eksperimen</h1><div class="card"><h2>${esc(e.aksi)}</h2><p><b>Hipotesis:</b> ${esc(e.hip)}</p><p><b>Ukuran:</b> ${esc(e.ukur)}</p><p class="mut">Hari ke-${e.log.length+1} dari ${e.hari}. Dicatat: ${e.log.length} hari. Hari tanpa catatan tidak dihitung gagal.</p></div>
  <label for="ob">Catat pengamatan hari ini</label><div class="fw"><textarea id="ob"></textarea></div>
  <div class="row" style="margin-top:10px"><button class="btn" onclick="logE()">Catat</button><button class="btn g" onclick="endE()">Hentikan</button></div>
  <div class="card" style="margin-top:12px">${e.log.map(l=>`<p>${esc(l)}</p>`).join('')||'<p class="mut">Belum ada pengamatan.</p>'}</div>
  <p class="note">Hasil akhir dibedakan: didukung, tidak didukung, atau belum jelas. Selesai menjalankan bukan berarti berhasil.</p>`;return}
 $('#v').innerHTML=`<h1>Eksperimen</h1><p class="mut">Satu eksperimen aktif agar tidak membebani.</p>
 <label for="ea">Tindakan yang diuji</label><input id="ea" placeholder="Istirahat singkat, lalu mulai tugas 5 menit">
 <label for="eh">Hipotesis</label><input id="eh" placeholder="Ini mungkin mengurangi penundaan">
 <label for="eu">Ukuran keberhasilan</label><input id="eu" placeholder="Berapa kali tugas benar-benar dimulai">
 <label for="ed">Durasi</label><select id="ed"><option>3</option><option selected>7</option><option>14</option></select><p class="hint">hari</p>
 <button class="btn" onclick="startE()">Mulai eksperimen</button>`}
function startE(){const a=$('#ea').value.trim();if(!a)return;S.exp={aksi:a,hip:$('#eh').value||'—',ukur:$('#eu').value||'—',hari:+$('#ed').value,log:[]};save();exper()}
function logE(){const t=$('#ob').value.trim();if(!t)return;S.exp.log.push(t);save();exper()}
function endE(){if(confirm('Hentikan eksperimen? Pengamatan tidak disimpan di preview ini.')){S.exp=null;save();exper()}}
function evo(){
 const days=[...Array(7)].map((_,i)=>{const d=new Date(Date.now()-(6-i)*864e5);return{k:dayKey(d),l:d.toLocaleDateString('id-ID',{weekday:'short'})}});
 const n=days.map(d=>S.entries.filter(e=>dayKey(e.t)==d.k).length);
 const mx=Math.max(1,...n);const have=S.entries.length>=3;
 $('#v').innerHTML=`<h1>Evolusi</h1><div class="card"><h2>Frekuensi jurnal, 7 hari</h2>
 ${have?`<div class="bars">${days.map((d,i)=>`<div class="bar">${n[i]?`<i style="height:${n[i]/mx*80}px"></i>${n[i]}`:'<b></b>—'}<span>${d.l}</span></div>`).join('')}</div>
 <p class="mut" style="margin-top:8px">Garis putus-putus berarti tidak ada data, bukan nol atau gagal.</p>`:
 `<p>Data belum cukup untuk menunjukkan pola.</p><p class="mut">Dibutuhkan minimal 3 jurnal. Saat ini ada ${S.entries.length}.</p>`}</div>
 ${(()=>{const lim=Date.now()-7*864e5;const F=(S.fl||[]).filter(x=>new Date(x.day+'T12:00').getTime()>lim);return `<div class="card"><h2>Tindakan 7 hari</h2>${F.length?`<p>${F.filter(x=>x.done).length} dilakukan, ${F.filter(x=>x.done===false).length} belum. Hari tanpa catatan tidak dihitung.</p>`:'<p class="mut">Data belum cukup untuk menunjukkan pola.</p>'}</div>`})()}<div class="card"><h2>Yang akan tampil nanti</h2><p class="mut">Konsistensi tindakan, energi dan kesehatan (dinilai sendiri), kualitas keputusan, eksperimen selesai, ringkasan mingguan dan bulanan, semuanya dari data nyata kamu.</p></div>`}
window.addEventListener('online',()=>tab==0&&home());window.addEventListener('offline',()=>tab==0&&home());

(async()=>{try{const s=await dbGet();if(s)Object.assign(S,s)}catch(e){}go(0)})();
if('serviceWorker' in navigator)addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));

function importJ(f){if(!f)return;const r=new FileReader();r.onload=()=>{try{const a=JSON.parse(r.result);
 if(!Array.isArray(a)||!a.every(e=>e&&typeof e.id=='number'&&typeof e.t=='number'))throw 0;
 const ids=new Set(S.entries.map(e=>e.id));let n=0;
 a.forEach(e=>{if(!ids.has(e.id)){S.entries.push({id:e.id,t:e.t,a:String(e.a||''),b:String(e.b||''),c:String(e.c||'')});n++}});
 S.entries.sort((x,y)=>y.t-x.t);save();hist();$('#sv').textContent='Impor selesai: '+n+' jurnal baru.'}catch(e){$('#sv').textContent='Berkas tidak valid. Impor dibatalkan.'}};r.readAsText(f)}

let nrec=false;
async function micNative(i,P){const st=$('#s'+i),ta=$('#f'+i),m=$('#m'+i);
 if(nrec){try{await P.stop()}catch(e){}return}
 const end=()=>{nrec=false;m.classList.remove('live');st.textContent='Selesai. Periksa dan koreksi teks bila perlu.'};
 try{const a=await P.available();if(!a.available){st.textContent='Dikte tidak tersedia di perangkat ini. Pakai mikrofon papan ketik.';return}
 const p=await P.requestPermissions();if(p.speechRecognition!=='granted'){st.textContent='Izin mikrofon ditolak.';return}
 const base=ta.value;await P.removeAllListeners();
 await P.addListener('partialResults',d=>{if(d.matches&&d.matches[0])ta.value=(base?base.replace(/\s*$/,' '):'')+d.matches[0]});
 await P.addListener('listeningState',d=>{if(d.status==='stopped')end()});
 nrec=true;m.classList.add('live');st.textContent='Mendengarkan... ketuk lagi untuk berhenti';
 await P.start({language:'id-ID',partialResults:true,popup:false})}catch(e){end();st.textContent='Dikte gagal. Pakai mikrofon papan ketik.'}}

const dn=()=>Math.floor(Date.now()/864e5);
const back='<button class="del" onclick="go(0)">← Beranda</button>';
const sub=n=>[vKompas,vReview,vRules,vDec][n]();
const ask=(id)=>$('#'+id).value.trim();
function ruleCard(){const R=S.rules||[];if(!R.length)return '';const r=R[dn()%R.length];return `<div class="card"><p class="sub" style="margin:0 0 4px">Dari buku aturanmu</p><p style="margin:0">Jika ${esc(r.jika)}, maka ${esc(r.maka)}.</p></div>`}
function vKompas(){const V=S.vals||[],fl=S.fl||[];
 $('#v').innerHTML=`${back}<h1>Kompas nilai</h1><p class="mut">Siapa yang ingin kamu jadi? Pilih maksimal 3 nilai. Buktinya adalah tindakan yang benar-benar kamu lakukan, bukan skor.</p>
 ${V.map(v=>{const t=fl.filter(x=>x.v==v.id),a=t.filter(x=>x.done);return `<div class="card"><h2>${esc(v.t)}</h2><p class="mut">${a.length} tindakan dilakukan dari ${t.length} yang dicatat untuk nilai ini.</p><button class="del" onclick="delV(${v.id})">Hapus</button></div>`}).join('')||'<p class="mut">Belum ada nilai.</p>'}
 ${V.length<3?`<label for="nv1">Aku ingin menjadi orang yang...</label><input id="nv1" placeholder="tenang saat tertekan"><button class="btn" style="margin-top:10px" onclick="addV()">Tambah nilai</button>`:''}
 <p class="note">Nilai adalah penilaian pribadimu, bukan ukuran ilmiah. Tidak ada skor total. Hubungkan tindakan harian ke nilai lewat kartu di Beranda.</p>`}
function addV(){const t=ask('nv1');if(!t)return;S.vals=(S.vals||[]).concat({id:Date.now(),t});save();vKompas()}
function delV(id){if(confirm('Hapus nilai ini?')){S.vals=S.vals.filter(v=>v.id!=id);save();vKompas()}}
function vReview(){const lim=Date.now()-7*864e5,E=S.entries.filter(e=>e.t>lim),F=(S.fl||[]).filter(x=>new Date(x.day+'T12:00').getTime()>lim);
 const ok=F.filter(x=>x.done).length,no=F.filter(x=>x.done===false).length;
 const en=Object.entries(S.en||{}).filter(([d])=>new Date(d+'T12:00').getTime()>lim).map(x=>x[1]);
 const avg=en.length?(en.reduce((a,b)=>a+b,0)/en.length).toFixed(1):null,L=E.filter(e=>e.b).slice(0,5);
 $('#v').innerHTML=`${back}<h1>Tinjauan mingguan</h1><p class="mut">Lima menit. Mulai dari data, bukan dari perasaan semata.</p>
 <div class="card"><h2>7 hari terakhir</h2><p>Jurnal: ${E.length}. Tindakan: ${ok} dilakukan, ${no} belum; hari tanpa catatan tidak dihitung gagal.</p><p>Energi: ${avg?'rata-rata '+avg+' dari '+en.length+' hari tercatat':'belum ada data'}.</p>${L.length?'<p class="sub">Yang kamu pelajari:</p>'+L.map(e=>`<p>• ${esc(e.b)}</p>`).join(''):''}${E.length<3?'<p class="mut">Data masih sedikit; tafsirkan dengan hati-hati.</p>':''}</div>
 <label for="r1">Apa yang berjalan?</label><textarea id="r1"></textarea>
 <label for="r2">Apa yang tidak sesuai rencana, dan mana yang di luar kendaliku?</label><textarea id="r2"></textarea>
 <label for="r3">Satu hal yang akan kuubah minggu depan</label><textarea id="r3"></textarea>
 <button class="btn" style="margin-top:10px" onclick="saveR()">Simpan tinjauan</button><div class="st" id="rs"></div>
 <h2 style="margin-top:20px">Tinjauan sebelumnya</h2><div class="card">${(S.rev||[]).map(r=>`<div class="ent"><span class="mut">${new Date(r.t).toLocaleDateString('id-ID',{dateStyle:'medium'})}</span><p><b>Ubah:</b> ${esc(r.c)}</p></div>`).join('')||'<p class="mut">Belum ada.</p>'}</div>`}
function saveR(){const a=ask('r1'),b=ask('r2'),c=ask('r3');if(!(a||b||c)){$('#rs').textContent='Isi minimal satu kolom.';return}S.rev=[{id:Date.now(),t:Date.now(),a,b,c}].concat(S.rev||[]);save();vReview()}
function vRules(){const R=S.rules||[];
 $('#v').innerHTML=`${back}<h1>Buku aturan pribadi</h1><p class="mut">Pelajaran yang sudah terbukti berguna, ditulis sebagai jika-maka. Satu aturan tampil di Beranda tiap hari.</p>
 <label for="ru1">Jika...</label><input id="ru1" placeholder="aku lelah dan menunda tugas"><label for="ru2">Maka aku akan...</label><input id="ru2" placeholder="istirahat 5 menit, lalu mulai 5 menit"><button class="btn" style="margin-top:10px" onclick="addR()">Simpan aturan</button>
 <div class="card" style="margin-top:14px">${R.map(r=>`<div class="ent"><p>Jika ${esc(r.jika)}, maka ${esc(r.maka)}.</p><button class="del" onclick="delR(${r.id})">Hapus</button></div>`).join('')||'<p class="mut">Belum ada aturan.</p>'}</div>
 <p class="note">Tulis aturan dari pengalaman yang sudah kamu uji, bukan dugaan.</p>`}
function addR(){const jika=ask('ru1'),maka=ask('ru2');if(!jika||!maka)return;S.rules=(S.rules||[]).concat({id:Date.now(),jika,maka});save();vRules()}
function delR(id){if(confirm('Hapus aturan ini?')){S.rules=S.rules.filter(r=>r.id!=id);save();vRules()}}
function vDec(){const D=S.dec||[],open=D.filter(d=>!d.hasil),done=D.filter(d=>d.hasil);
 const cal=done.length>=5?(()=>{const y=Math.round(done.reduce((a,d)=>a+d.yakin,0)/done.length),h=Math.round(done.filter(d=>d.hasil.ok).length/done.length*100);return `Rata-rata keyakinan awal ${y}%, hasil sesuai harapan ${h}%. Selisih besar berarti kamu cenderung ${y>h?'terlalu percaya diri':'terlalu ragu'}. Ini perkiraan kasar dari ${done.length} keputusan.`})():`Kalibrasi keyakinan muncul setelah minimal 5 keputusan selesai (sekarang ${done.length}).`;
 $('#v').innerHTML=`${back}<h1>Decision Lab</h1><p class="mut">Catat keputusan penting sebelum hasilnya diketahui. Hasil buruk tidak selalu berarti keputusan buruk.</p>
 <label for="d1">Keputusan yang dipertimbangkan</label><input id="d1"><label for="d2">Pilihan alternatif</label><input id="d2"><label for="d3">Yang belum kuketahui</label><input id="d3"><label for="d4">Aku akan tinjau ulang jika...</label><input id="d4">
 <label for="d5">Seberapa yakin ini keputusan tepat? <span id="dv">70</span>%</label><input id="d5" type="range" min="50" max="95" step="5" value="70" oninput="$('#dv').textContent=this.value">
 <button class="btn" style="margin-top:10px" onclick="addD()">Simpan keputusan</button>
 <h2 style="margin-top:20px">Menunggu hasil</h2><div class="card">${open.map(d=>`<div class="ent"><b>${esc(d.m)}</b><p class="mut">Yakin ${d.yakin}%. Belum diketahui: ${esc(d.u||'—')}</p><button class="btn g" onclick="closeD(${d.id})">Catat hasil</button></div>`).join('')||'<p class="mut">Tidak ada.</p>'}</div>
 <h2 style="margin-top:16px">Selesai</h2><div class="card">${done.map(d=>`<div class="ent"><b>${esc(d.m)}</b><p class="mut">Hasil sesuai harapan: ${d.hasil.ok?'ya':'tidak'}. Kualitas proses saat itu: ${d.hasil.proses}.</p><p>${esc(d.hasil.pel)}</p></div>`).join('')||'<p class="mut">Belum ada.</p>'}</div><p class="note">${cal}</p>`}
function addD(){const m=ask('d1');if(!m)return;S.dec=[{id:Date.now(),t:Date.now(),m,alt:ask('d2'),u:ask('d3'),tinjau:ask('d4'),yakin:+$('#d5').value,hasil:null}].concat(S.dec||[]);save();vDec()}
function closeD(id){const d=S.dec.find(x=>x.id==id);if(!d)return;const ok=confirm('Apakah hasilnya sesuai harapanmu? OK = ya, Batal = tidak');
 let p=(prompt('Kualitas proses berpikirmu saat itu: baik, cukup, atau lemah?','cukup')||'cukup').toLowerCase();if(!['baik','cukup','lemah'].includes(p))p='cukup';
 d.hasil={ok,proses:p,pel:prompt('Pelajaran yang bisa dipakai lagi? (boleh kosong)')||''};save();vDec()}
