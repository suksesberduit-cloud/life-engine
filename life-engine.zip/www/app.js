
const $=s=>document.querySelector(s);
let S={entries:[],exp:null};
const DB=()=>new Promise((res,rej)=>{const r=indexedDB.open('lie',1);r.onupgradeneeded=()=>r.result.createObjectStore('kv');r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
async function dbGet(){const d=await DB();return new Promise(res=>{const q=d.transaction('kv').objectStore('kv').get('state');q.onsuccess=()=>res(q.result);q.onerror=()=>res(null)})}
async function dbSet(v){const d=await DB();return new Promise((res,rej)=>{const t=d.transaction('kv','readwrite');t.objectStore('kv').put(v,'state');t.oncomplete=res;t.onerror=()=>rej(t.error)})}
let saveErr=false;
const save=()=>{dbSet(JSON.parse(JSON.stringify(S))).then(()=>{saveErr=false}).catch(()=>{saveErr=true;alert('Gagal menyimpan ke penyimpanan lokal. Ekspor data sekarang sebagai cadangan.')})};
const esc=t=>String(t).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const I={
 home:'<path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
 book:'<path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3zM5 17a3 3 0 0 1 3-3h11"/>',
 chk:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-5-5M8 11l2 2 4-4"/>',
 exp:'<path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 2 3h10a2 2 0 0 0 2-3l-5-9V3"/>',
 evo:'<path d="M3 20h18M6 16l4-5 4 3 5-8"/>',
 mic:'<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>'};
const ic=(k)=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${I[k]}</svg>`;
const TABS=[['home','Beranda'],['book','Diary'],['chk','Checker'],['exp','Eksperimen'],['evo','Evolusi'],['evo','Life OS']];
let tab=0;
function go(i){tab=i;
 $('#nv').innerHTML=TABS.map((t,j)=>`<button onclick="go(${j})" ${j==i?'aria-current="true"':''}>${ic(t[0])}${t[1]}</button>`).join('');
 [home,diary,checker,exper,evo,lifeOS][i]();window.scrollTo(0,0)}
const dayKey=d=>new Date(d).toLocaleDateString('sv-SE');
function home(){
 const today=S.entries.filter(e=>dayKey(e.t)==dayKey(Date.now())).length;
 const on=navigator.onLine;
 $('#v').innerHTML=`<p class="mut">${new Date().toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long',year:'numeric'})}</p>
 <h1>Selamat datang</h1><p class="mut">Catat pengalaman. Periksa kenyataan. Pahami pola. Uji perbaikan. Evaluasi bukti.</p>
 ${focusCard()}${ruleCard()}
 <div class="chips"><span class="chip on">Penyimpanan lokal</span><span class="chip ${on?'on':'wr'}">${on?'Online':'Offline'}</span><span class="chip wr">AI: belum dikonfigurasi</span></div>
 <div class="card"><h2>Hari ini</h2><p>${today?today+' catatan tersimpan.':'Belum ada catatan hari ini. Tidak apa-apa.'}</p></div>
 <div class="card"><h2>Eksperimen berjalan</h2><p>${S.exp?esc(S.exp.aksi)+' — hari ke-'+(S.exp.log.length+1)+' dari '+S.exp.hari:'Belum ada. Buka tab Eksperimen untuk memulai satu.'}</p></div>
 <div class="card"><h2>Alat pertumbuhan</h2><div class="row"><button class="btn g" onclick="sub(0)">Kompas nilai</button><button class="btn g" onclick="sub(1)">Tinjauan mingguan</button></div><div class="row" style="margin-top:8px"><button class="btn g" onclick="sub(2)">Buku aturan</button><button class="btn g" onclick="sub(3)">Decision Lab</button></div><div class="row" style="margin-top:8px"><button class="btn g" onclick="sub(4)">Pengingat harian</button><button class="btn g" onclick="vQuick()">Check-in cepat</button></div><div class="row" style="margin-top:8px"><button class="btn" onclick="go(5)">Buka Life OS</button></div></div><p class="note">Data tersimpan hanya di perangkat ini. Ekspor berkala sebagai cadangan; data hilang jika aplikasi dihapus atau data browser dibersihkan.</p>`}
function focusCard(){const k=dayKey(Date.now());const f=S.focus&&S.focus.day==k?S.focus:null;const last=S.entries.find(e=>e.c);const en=(S.en||{})[k];let top;
 if(f){top=`<p style="font:600 20px/1.35 Newsreader,Georgia,serif;margin:6px 0 12px">${esc(f.text)}</p>`+(f.done==null?`<div class="row"><button class="btn" onclick="markF(true)">Sudah dilakukan</button><button class="btn g" onclick="markF(false)">Belum</button></div>`:`<p class="mut">${f.done?'Tercatat: dilakukan.':'Tercatat: belum dilakukan. Itu data, bukan kegagalan.'} <button class="del" onclick="resetF()">Ubah</button></p>`)}
 else top=`<input id="fi" aria-label="Tindakan kecil hari ini" placeholder="Contoh: mulai tugas 5 menit setelah istirahat" value="${last?esc(last.c):''}">${S.vals&&S.vals.length?`<select id="fv" aria-label="Untuk nilai" style="margin-top:8px"><option value="">Tanpa nilai</option>${S.vals.map(v=>`<option value="${v.id}">${esc(v.t)}</option>`).join('')}</select>`:''}<div class="row" style="margin-top:8px"><button class="btn" onclick="setF()">Tetapkan</button></div>${last?'<p class="hint" style="margin-top:6px">Terisi dari kolom perbaiki di catatan terakhirmu. Ubah bila perlu.</p>':'<p class="hint" style="margin-top:6px">Pilih satu hal kecil yang realistis. Nanti malam kamu cukup menjawab: sudah atau belum.</p>'}`;
 return `<div class="hero"><h2>Satu tindakan kecil hari ini</h2>${top}<p class="sub">Energi saat ini (opsional)</p><div class="row">${[1,2,3,4,5].map(n=>`<button class="en ${en==n?'sel':''}" aria-label="Energi ${n} dari 5" onclick="setEn(${n})">${n}</button>`).join('')}</div>
 <div class="row" style="margin-top:14px"><button class="btn g" onclick="go(1);setTimeout(()=>{document.getElementById('f0').focus();mic(0)},80)">${ic('mic')}Catat suara</button><button class="btn g" onclick="go(1);setTimeout(()=>document.getElementById('f0').focus(),50)">Tulis</button></div></div>`}
function setF(){const t=$('#fi').value.trim();if(!t)return;S.focus={day:dayKey(Date.now()),text:t,done:null,v:+(($("#fv")||{}).value||0)};save();home()}
function markF(v){S.focus.done=v;S.fl=(S.fl||[]).filter(x=>x.day!=S.focus.day);S.fl.push({day:S.focus.day,text:S.focus.text,done:v,v:S.focus.v});save();home()}
function resetF(){S.fl=(S.fl||[]).filter(x=>x.day!=S.focus.day);S.focus=null;save();home()}
function setEn(n){S.en=S.en||{};S.en[dayKey(Date.now())]=n;save();home()}
const FIELDS=[['Apa yang benar-benar terjadi?','Ceritakan pengalaman hari ini tanpa buru-buru menghakimi diri.','Hari ini aku mengalami...'],
['Apa yang kupelajari?','Apa yang kusadari tentang fakta, asumsi, emosi, atau pola yang mungkin berulang?','Hal yang kupelajari hari ini...'],
['Apa yang akan kuperbaiki?','Satu tindakan kecil yang realistis untuk langkah berikutnya.','Satu tindakan kecil berikutnya...']];
function field(i){const f=FIELDS[i];return `<label for="f${i}">${f[0]}</label><p class="hint">${f[1]}</p>
 <div class="fw"><textarea id="f${i}" placeholder="${f[2]}"></textarea><button class="mic" id="m${i}" aria-label="Dikte untuk kolom: ${f[0]}" onclick="mic(${i})">${ic('mic')}</button></div><div class="st" id="s${i}">Siap</div>`}
function diary(){
 $('#v').innerHTML=`<h1>Diary</h1>${[0,1,2].map(field).join('')}
 <div class="row" style="margin-top:14px"><button class="btn" onclick="saveEntry()">Simpan jurnal</button><button class="btn g" onclick="exportJ()">Ekspor</button><button class="btn g" onclick="$('#imp').click()">Impor</button></div><input id="imp" type="file" accept="application/json" hidden onchange="importJ(this.files[0])"><div class="st" id="sv"></div>
 <h2 style="margin-top:22px">Riwayat</h2><input id="q" placeholder="Cari jurnal" oninput="hist()"><div class="card" id="h" style="margin-top:10px"></div>`;hist()}
function saveEntry(){const v=[0,1,2].map(i=>$('#f'+i).value.trim());
 if(!v.some(Boolean)){$('#sv').textContent='Isi minimal satu kolom.';return}
 S.entries.unshift({id:Date.now(),t:Date.now(),a:v[0],b:v[1],c:v[2]});save();
 [0,1,2].forEach(i=>$('#f'+i).value='');$('#sv').textContent='Tersimpan di perangkat ini.';hist()}
function hist(){const q=($('#q')?.value||'').toLowerCase();
 const L=S.entries.filter(e=>(e.a+e.b+e.c).toLowerCase().includes(q));
 $('#h').innerHTML=L.length?L.map(e=>`<div class="ent"><span class="mut">${new Date(e.t).toLocaleString('id-ID',{dateStyle:'medium',timeStyle:'short'})}</span>
 ${[e.a,e.b,e.c].map((x,i)=>x?`<p><b>${['Terjadi','Dipelajari','Perbaiki'][i]}:</b> ${esc(x)}</p>`:'').join('')}
 <button class="del" onclick="delE(${e.id})">Hapus</button></div>`).join(''):'<p class="mut">Belum ada jurnal yang cocok.</p>'}
function delE(id){if(confirm('Hapus jurnal ini?')){S.entries=S.entries.filter(e=>e.id!=id);save();hist()}}
function exportJ(){exportAll()}
function exportAll(){const payload={app:'The Life Intelligence Engine',schemaVersion:2,exportedAt:new Date().toISOString(),data:S};const b=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});const u=URL.createObjectURL(b);const a=document.createElement('a');a.href=u;a.download='life-intelligence-backup-'+dayKey(Date.now())+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1500);const st=$('#sv')||$('#lifeStatus');if(st)st.textContent='Backup lengkap dibuat. Simpan di lokasi aman; file ini belum dienkripsi.'}
let rec=null,recI=-1;
function mic(i){const NP=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.SpeechRecognition;if(NP){micNative(i,NP);return}const SR=window.SpeechRecognition||window.webkitSpeechRecognition;const st=$('#s'+i);
 if(!SR){st.textContent='Dikte tidak didukung di browser ini. Ketik manual, atau pakai ikon mikrofon di papan ketik Android.';return}
 if(rec){rec.stop();return}
 const ta=$('#f'+i);const base=ta.value;let fin='';
 rec=new SR();recI=i;rec.lang='id-ID';rec.interimResults=true;rec.continuous=true;
 rec.onstart=()=>{$('#m'+i).classList.add('live');st.textContent='Mendengarkan... ketuk lagi untuk berhenti'};
 rec.onresult=ev=>{let it='';for(let k=ev.resultIndex;k<ev.results.length;k++){const r=ev.results[k];if(r.isFinal)fin+=r[0].transcript+' ';else it+=r[0].transcript}
  ta.value=(base?base.replace(/\s*$/,' '):'')+fin+it;st.textContent='Mengubah suara menjadi teks...'};
 rec.onerror=e=>{st.textContent=e.error=='not-allowed'||e.error=='service-not-allowed'?'Izin mikrofon ditolak atau diblokir di sini.':e.error=='network'?'Koneksi diperlukan untuk dikte.':'Terjadi kesalahan: '+e.error};
 rec.onend=()=>{$('#m'+i)?.classList.remove('live');if(/Mendengarkan|Mengubah/.test(st.textContent))st.textContent='Selesai. Periksa dan koreksi teks bila perlu.';rec=null};
 try{rec.start()}catch(e){st.textContent='Tidak bisa memulai dikte.';rec=null}}
const RULES=[[/(sepertinya|kayaknya|mungkin|pasti|jelas)/i,'i'],[/(selalu|tidak pernah|semua|sama sekali)/i,'i'],[/(tidak pandai|bodoh|gagal total|payah|tidak mampu)/i,'i'],[/(merasa|sedih|cemas|kesal|takut|senang|lelah|capek)/i,'n']];
function checker(){
 $('#v').innerHTML=`<h1>Checker</h1><p class="mut">Pemeriksaan lokal berbasis kata kunci sederhana. Ini bukan AI dan bukan vonis.</p>
 <label for="ck">Tulis satu pengalaman</label><div class="fw"><textarea id="ck" placeholder="Usaha hari ini sepi. Sepertinya aku tidak pandai mengelola bisnis."></textarea></div>
 <button class="btn" style="margin-top:10px" onclick="runCk()">Periksa</button><div id="ckr"></div>`}
function runCk(){const t=$('#ck').value.trim();if(!t)return;
 const ss=t.split(/(?<=[.!?])\s+/).filter(Boolean);let gen=false;
 const rows=ss.map(s=>{let k='f';for(const [re,x] of RULES)if(re.test(s)){k=x;break}
  if(/(selalu|tidak pernah|semua|tidak pandai|gagal total)/i.test(s))gen=true;
  return `<p><span class="tag t-${k}">${{f:'Fakta (kandidat)',i:'Interpretasi / asumsi',n:'Emosi'}[k]}</span>${esc(s)}</p>`}).join('');
 $('#ckr').innerHTML=`<div class="card" style="margin-top:12px"><h2>Pemisahan</h2>${rows}</div>
 <div class="card"><h2>Penjelasan alternatif</h2><p>Faktor di luar kendali yang belum diperiksa: cuaca, daya beli, persaingan, stok, harga, musim.</p></div>
 <div class="card"><h2>Pertanyaan penguji</h2><p>${gen?'Ini mungkin mengandung generalisasi berlebihan. Apakah ada bukti yang mendukung atau membantahnya?':'Bukti apa yang bisa kamu cek untuk membedakan fakta dari dugaan?'} Apakah hari sepi serupa terjadi minggu lalu?</p>
 <p><b>Tingkat keyakinan:</b> dugaan awal (satu kejadian belum cukup untuk kesimpulan).</p>
 <button class="btn g" onclick="go(3)">Jadikan eksperimen</button></div>`}
function exper(){
 if(S.exp){const e=S.exp;
  $('#v').innerHTML=`<h1>Eksperimen</h1><div class="card"><h2>${esc(e.aksi)}</h2><p><b>Hipotesis:</b> ${esc(e.hip)}</p><p><b>Ukuran:</b> ${esc(e.ukur)}</p><p class="mut">Hari ke-${e.log.length+1} dari ${e.hari}. Dicatat: ${e.log.length} hari. Hari tanpa catatan tidak dihitung gagal.</p></div>
  <label for="ob">Catat pengamatan hari ini</label><div class="fw"><textarea id="ob"></textarea></div>
  <div class="row" style="margin-top:10px"><button class="btn" onclick="logE()">Catat</button><button class="btn g" onclick="endE()">Hentikan</button></div>
  <div class="card" style="margin-top:12px">${e.log.map(l=>`<p>${esc(l)}</p>`).join('')||'<p class="mut">Belum ada pengamatan.</p>'}</div>
  <p class="note">Hasil akhir dibedakan: didukung, tidak didukung, atau belum jelas. Selesai menjalankan bukan berarti berhasil.</p>${(S.expHistory||[]).length?`<h2>Arsip eksperimen</h2><div class="card">${S.expHistory.map(x=>`<div class="ent"><b>${esc(x.aksi)}</b><p class="mut">${esc(x.status||'selesai')} · ${x.log.length} pengamatan</p>${x.log.map(y=>`<p>${esc(y)}</p>`).join('')}</div>`).join('')}</div>`:''}`;return}
 $('#v').innerHTML=`<h1>Eksperimen</h1><p class="mut">Satu eksperimen aktif agar tidak membebani.</p>
 <label for="ea">Tindakan yang diuji</label><input id="ea" placeholder="Istirahat singkat, lalu mulai tugas 5 menit">
 <label for="eh">Hipotesis</label><input id="eh" placeholder="Ini mungkin mengurangi penundaan">
 <label for="eu">Ukuran keberhasilan</label><input id="eu" placeholder="Berapa kali tugas benar-benar dimulai">
 <label for="ed">Durasi</label><select id="ed"><option>3</option><option selected>7</option><option>14</option></select><p class="hint">hari</p>
 <button class="btn" onclick="startE()">Mulai eksperimen</button>`}
function startE(){const a=$('#ea').value.trim();if(!a)return;S.exp={aksi:a,hip:$('#eh').value||'—',ukur:$('#eu').value||'—',hari:+$('#ed').value,log:[]};save();exper()}
function logE(){const t=$('#ob').value.trim();if(!t)return;S.exp.log.push(t);save();exper()}
function endE(){if(confirm('Akhiri eksperimen dan arsipkan semua pengamatan?')){S.expHistory=S.expHistory||[];S.expHistory.unshift({...S.exp,endedAt:Date.now(),status:'dihentikan'});S.exp=null;save();exper()}}
function evo(){
 const days=[...Array(7)].map((_,i)=>{const d=new Date(Date.now()-(6-i)*864e5);return{k:dayKey(d),l:d.toLocaleDateString('id-ID',{weekday:'short'})}});
 const n=days.map(d=>S.entries.filter(e=>dayKey(e.t)==d.k).length);
 const mx=Math.max(1,...n);const have=S.entries.length>=3;
 $('#v').innerHTML=`<h1>Evolusi</h1><div class="card"><h2>Frekuensi jurnal, 7 hari</h2>
 ${have?`<div class="bars">${days.map((d,i)=>`<div class="bar">${n[i]?`<i style="height:${n[i]/mx*80}px"></i>${n[i]}`:'<b></b>—'}<span>${d.l}</span></div>`).join('')}</div>
 <p class="mut" style="margin-top:8px">Garis putus-putus berarti tidak ada data, bukan nol atau gagal.</p>`:
 `<p>Data belum cukup untuk menunjukkan pola.</p><p class="mut">Dibutuhkan minimal 3 jurnal. Saat ini ada ${S.entries.length}.</p>`}</div>
 ${(()=>{const lim=Date.now()-7*864e5;const F=(S.fl||[]).filter(x=>new Date(x.day+'T12:00').getTime()>lim);return `<div class="card"><h2>Tindakan 7 hari</h2>${F.length?`<p>${F.filter(x=>x.done).length} dilakukan, ${F.filter(x=>x.done===false).length} belum. Hari tanpa catatan tidak dihitung.</p>`:'<p class="mut">Data belum cukup untuk menunjukkan pola.</p>'}</div>`})()}<div class="card"><h2>Yang akan tampil nanti</h2><p class="mut">Konsistensi tindakan, energi dan kesehatan (dinilai sendiri), kualitas keputusan, eksperimen selesai, ringkasan mingguan dan bulanan, semuanya dari data nyata kamu.</p></div>`}
// LIFE OS v1.0 — optional reflection modules, local-first and evidence-aware.
const LIFE_AREAS=['Fisik & energi','Keluarga & hubungan','Kebebasan finansial','Waktu luang & kesenangan','Belajar & pertumbuhan','Ketenangan batin'];
function lifeOS(){
 S.wisdom=S.wisdom||[];S.predictions=S.predictions||[];S.timeline=S.timeline||[];S.bal=S.bal||{};S.honesty=S.honesty||[];
 const b=LIFE_AREAS.map((a,i)=>`<label>${a}</label><input type="range" min="1" max="5" value="${S.bal[i]||3}" oninput="S.bal[${i}]=+this.value;this.nextElementSibling.textContent=this.value+'/5';save()"><span class="mut">${S.bal[i]||3}/5 — penilaian pribadi, bukan ukuran objektif</span>`).join('');
 $('#v').innerHTML=`<p class="mut">THE LIFE INTELLIGENCE ENGINE · v1.0</p><h1>Life OS</h1><p class="mut">Sistem untuk memahami diri, menguji pikiran, menggunakan waktu dengan sengaja, dan menentukan arti cukup. Tidak semua hal perlu diberi skor.</p>
 <div class="card"><h2>1. Life Balance</h2><p class="mut">Tinjau enam ranah. Nilai boleh berubah; jangan jadikan angka sebagai perlombaan.</p>${b}</div>
 <div class="card"><h2>2. Intellectual Honesty Protocol</h2><p class="mut">Gunakan saat menghadapi keputusan atau keyakinan penting.</p>
 <label>Observation — apa yang benar-benar terjadi?</label><textarea id="ho1" placeholder="Data atau kejadian yang bisa diverifikasi"></textarea>
 <label>Interpretation — apa maknanya menurutku?</label><textarea id="ho2"></textarea>
 <label>Assumption Audit — asumsi apa yang belum terbukti?</label><textarea id="ho3"></textarea>
 <label>Counterargument — argumen terkuat yang menentangku?</label><textarea id="ho4"></textarea>
 <label>Evidence Test — bukti apa yang bisa membuktikan aku salah?</label><textarea id="ho5"></textarea>
 <label>Belief Revision — apa yang akan kuubah atau pertahankan?</label><textarea id="ho6"></textarea>
 <button class="btn" style="margin-top:10px" onclick="saveHonesty()">Simpan audit pikiran</button>${S.honesty.map(x=>`<div class="ent"><span class="mut">${new Date(x.t).toLocaleDateString('id-ID')}</span><p><b>Fakta:</b> ${esc(x.observation||'—')}</p><p><b>Asumsi:</b> ${esc(x.assumptions||'—')}</p><p><b>Kontra-argumen:</b> ${esc(x.counterargument||'—')}</p><p><b>Revisi:</b> ${esc(x.revision||'—')}</p></div>`).join('')||'<p class="mut">Belum ada audit pikiran.</p>'}</div>
 <div class="card"><h2>3. Prediction Journal</h2><p class="mut">Catat prediksi SEBELUM hasil diketahui. Ini melatih kalibrasi, bukan meramal masa depan.</p>
 <label>Prediksi yang bisa diperiksa</label><input id="pr1" placeholder="Dalam 30 hari, ...">
 <label>Probabilitas keyakinan</label><input id="pr2" type="number" min="1" max="99" value="70">
 <label>Tanggal evaluasi</label><input id="pr3" type="date">
 <button class="btn" style="margin-top:10px" onclick="savePrediction()">Simpan prediksi</button>
 ${S.predictions.map(x=>`<div class="ent"><b>${esc(x.text)}</b><p class="mut">Keyakinan ${x.confidence}% · evaluasi ${esc(x.due||'belum ditentukan')} · ${x.outcome?'selesai':'menunggu'}</p>${x.outcome?`<p>${esc(x.outcome)}</p>`:`<button class="btn g" onclick="resolvePrediction(${x.id})">Evaluasi hasil</button>`}</div>`).join('')||'<p class="mut">Belum ada prediksi.</p>'}</div>
 <div class="card"><h2>4. Wisdom Bank</h2><p class="mut">Simpan pelajaran, kesalahan, prinsip, dan hipotesis. Tandai mana yang sudah diuji.</p>
 <label>Pelajaran / prinsip / pertanyaan</label><textarea id="wi1" placeholder="Apa yang ingin kuingat?"></textarea><label>Jenis</label><select id="wi2"><option>Pengalaman</option><option>Kesalahan</option><option>Penemuan</option><option>Prinsip hidup</option><option>Hipotesis belum terbukti</option></select><label>Status bukti</label><select id="wi3"><option>Belum diuji</option><option>Sudah diuji sekali</option><option>Berulang kali teruji</option></select><button class="btn" style="margin-top:10px" onclick="saveWisdom()">Simpan ke Wisdom Bank</button>
 ${S.wisdom.map(x=>`<div class="ent"><b>${esc(x.kind)}</b> · <span class="mut">${esc(x.status)}</span><p>${esc(x.text)}</p><button class="del" onclick="deleteWisdom(${x.id})">Hapus</button></div>`).join('')||'<p class="mut">Belum ada catatan kebijaksanaan.</p>'}</div>
 <div class="card"><h2>5. Life Timeline & Regret Minimization</h2><p class="mut">Apa yang ingin dialami, bukan hanya dicapai? Catat hal yang tak ingin terus ditunda.</p>
 <label>Pengalaman / milestone yang bermakna</label><input id="ti1" placeholder="Misalnya: perjalanan, waktu bersama keluarga, karya..."><label>Horizon</label><select id="ti2"><option>Dalam 1 tahun</option><option>Dalam 5 tahun</option><option>Dalam 10 tahun</option><option>Suatu hari, tanpa tanggal</option></select><button class="btn" style="margin-top:10px" onclick="saveTimeline()">Simpan niat</button>
 ${S.timeline.map(x=>`<div class="ent"><b>${esc(x.horizon)}</b><p>${esc(x.text)}</p><button class="del" onclick="deleteTimeline(${x.id})">Hapus</button></div>`).join('')||'<p class="mut">Belum ada niat yang dicatat.</p>'}</div>
 <div class="card"><h2>6. Enoughness & Financial Freedom</h2><p class="mut">Pisahkan kebutuhan, pendapatan pasif, dan margin keamanan. Angka di sini adalah catatan pribadi, bukan rekomendasi investasi.</p>
 <label>Pengeluaran hidup per bulan (Rp)</label><input id="ef1" type="number" min="0" value="${S.enough?.expense??''}" placeholder="Contoh 3600000">
 <label>Pendapatan pasif bersih per bulan (Rp)</label><input id="ef2" type="number" min="0" value="${S.enough?.income??''}" placeholder="Contoh 4500000">
 <label>Cadangan likuid (bulan pengeluaran)</label><input id="ef3" type="number" min="0" step="0.5" value="${S.enough?.buffer??''}" placeholder="Contoh 12">
 <button class="btn" style="margin-top:10px" onclick="saveEnough()">Simpan angka kecukupan</button>
 ${S.enough?`<p style="margin-top:12px"><b>Cakupan pendapatan pasif:</b> ${S.enough.expense>0?Math.round(S.enough.income/S.enough.expense*100):0}% dari pengeluaran tercatat.</p><p><b>Margin:</b> Rp${(S.enough.income-S.enough.expense).toLocaleString('id-ID')} per bulan.</p><p><b>Cadangan:</b> ${S.enough.buffer} bulan.</p>`:''}
 <p class="note">Peringatan goalpost moving: saat target tercapai, evaluasi apakah target baru benar-benar menambah kualitas hidup atau hanya memindahkan garis finis.</p></div>
 <div class="card"><h2>7. Backup seluruh kehidupan digital</h2><p class="mut">Ekspor seluruh state: jurnal, nilai, tindakan, energi, eksperimen, keputusan, aturan, tinjauan, prediksi, wisdom, timeline, dan pengaturan.</p><div class="row"><button class="btn" onclick="exportAll()">Ekspor backup lengkap</button><button class="btn g" onclick="$('#lifeimp').click()">Impor backup</button></div><input id="lifeimp" type="file" accept="application/json" hidden onchange="importJ(this.files[0])"><div class="st" id="lifeStatus"></div><p class="note">Backup JSON berisi data pribadi dan belum dienkripsi. Simpan di tempat privat. Ekspor sebelum menghapus aplikasi atau membersihkan data browser.</p></div>`;
}
function saveHonesty(){const v=[1,2,3,4,5,6].map(i=>$('#ho'+i).value.trim());if(!v.some(Boolean))return alert('Isi minimal satu bagian.');S.honesty.unshift({id:Date.now(),t:Date.now(),observation:v[0],interpretation:v[1],assumptions:v[2],counterargument:v[3],evidence:v[4],revision:v[5]});save();lifeOS()}
function savePrediction(){const text=$('#pr1').value.trim(),confidence=+$('#pr2').value,due=$('#pr3').value;if(!text||confidence<1||confidence>99)return alert('Isi prediksi dan probabilitas 1–99%.');S.predictions.unshift({id:Date.now(),text,confidence,due,outcome:null});save();lifeOS()}
function resolvePrediction(id){const x=S.predictions.find(p=>p.id===id);if(!x)return;const outcome=prompt('Apa hasil yang benar-benar terjadi?');if(outcome===null)return;x.outcome=outcome||'Hasil tidak dicatat';x.resolvedAt=Date.now();save();lifeOS()}
function saveWisdom(){const text=$('#wi1').value.trim();if(!text)return;S.wisdom.unshift({id:Date.now(),text,kind:$('#wi2').value,status:$('#wi3').value,t:Date.now()});save();lifeOS()}
function deleteWisdom(id){if(confirm('Hapus catatan ini?')){S.wisdom=S.wisdom.filter(x=>x.id!==id);save();lifeOS()}}
function saveTimeline(){const text=$('#ti1').value.trim();if(!text)return;S.timeline.unshift({id:Date.now(),text,horizon:$('#ti2').value,t:Date.now()});save();lifeOS()}
function deleteTimeline(id){if(confirm('Hapus niat ini?')){S.timeline=S.timeline.filter(x=>x.id!==id);save();lifeOS()}}
function saveEnough(){const expense=+$('#ef1').value,income=+$('#ef2').value,buffer=+$('#ef3').value;if(expense<0||income<0||buffer<0)return alert('Angka tidak boleh negatif.');S.enough={expense,income,buffer,updatedAt:Date.now()};save();lifeOS()}

window.addEventListener('online',()=>tab==0&&home());window.addEventListener('offline',()=>tab==0&&home());

(async()=>{try{const s=await dbGet();if(s)Object.assign(S,s)}catch(e){}go(0);hookNotif();applyRem(false).catch(()=>{})})();
if('serviceWorker' in navigator)addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));

function importJ(f){if(!f)return;const r=new FileReader();r.onload=()=>{try{const raw=JSON.parse(r.result);let incoming;
 if(Array.isArray(raw)){if(!raw.every(e=>e&&typeof e.id==='number'&&typeof e.t==='number'))throw Error('legacy');incoming={entries:raw}}
 else if(raw&&raw.app==='The Life Intelligence Engine'&&raw.schemaVersion===2&&raw.data&&Array.isArray(raw.data.entries))incoming=raw.data;
 else throw Error('format');
 if(!confirm('Impor akan MENGGABUNGKAN jurnal dan mengganti data modul lain yang memiliki pasangan di backup. Lanjutkan?'))return;
 if(Array.isArray(incoming.entries)){const ids=new Set(S.entries.map(e=>e.id));incoming.entries.forEach(e=>{if(!ids.has(e.id))S.entries.push(e)});S.entries.sort((a,b)=>b.t-a.t)}
 Object.keys(incoming).filter(k=>k!=='entries').forEach(k=>{S[k]=incoming[k]});save();if($('#h'))hist();if($('#sv'))$('#sv').textContent='Impor berhasil. Jurnal digabungkan; data modul lain dipulihkan dari backup.';else go(0);
 }catch(e){const st=$('#sv');if(st)st.textContent='Berkas tidak valid atau versi tidak didukung. Tidak ada perubahan.';else alert('Berkas tidak valid atau versi tidak didukung.')}};r.readAsText(f)}

let nrec=false;
async function micNative(i,P){const st=$('#s'+i),ta=$('#f'+i),m=$('#m'+i);
 if(nrec){try{await P.stop()}catch(e){}return}
 const end=()=>{nrec=false;m.classList.remove('live');st.textContent='Selesai. Periksa dan koreksi teks bila perlu.'};
 try{const a=await P.available();if(!a.available){st.textContent='Dikte tidak tersedia di perangkat ini. Pakai mikrofon papan ketik.';return}
 const p=await P.requestPermissions();if(p.speechRecognition!=='granted'){st.textContent='Izin mikrofon ditolak.';return}
 const base=ta.value;await P.removeAllListeners();
 await P.addListener('partialResults',d=>{if(d.matches&&d.matches[0])ta.value=(base?base.replace(/\s*$/,' '):'')+d.matches[0]});
 await P.addListener('listeningState',d=>{if(d.status==='stopped')end()});
 nrec=true;m.classList.add('live');st.textContent='Mendengarkan... ketuk lagi untuk berhenti';
 await P.start({language:'id-ID',partialResults:true,popup:false})}catch(e){end();st.textContent='Dikte gagal. Pakai mikrofon papan ketik.'}}

const dn=()=>Math.floor(Date.now()/864e5);
const back='<button class="del" onclick="go(0)">← Beranda</button>';
const sub=n=>[vKompas,vReview,vRules,vDec,vSet][n]();
const ask=(id)=>$('#'+id).value.trim();
function ruleCard(){const R=S.rules||[];if(!R.length)return '';const r=R[dn()%R.length];return `<div class="card"><p class="sub" style="margin:0 0 4px">Dari buku aturanmu</p><p style="margin:0">Jika ${esc(r.jika)}, maka ${esc(r.maka)}.</p></div>`}
function vKompas(){const V=S.vals||[],fl=S.fl||[];
 $('#v').innerHTML=`${back}<h1>Kompas nilai</h1><p class="mut">Siapa yang ingin kamu jadi? Pilih maksimal 3 nilai. Buktinya adalah tindakan yang benar-benar kamu lakukan, bukan skor.</p>
 ${V.map(v=>{const t=fl.filter(x=>x.v==v.id),a=t.filter(x=>x.done);return `<div class="card"><h2>${esc(v.t)}</h2><p class="mut">${a.length} tindakan dilakukan dari ${t.length} yang dicatat untuk nilai ini.</p><button class="del" onclick="delV(${v.id})">Hapus</button></div>`}).join('')||'<p class="mut">Belum ada nilai.</p>'}
 ${V.length<3?`<label for="nv1">Aku ingin menjadi orang yang...</label><input id="nv1" placeholder="tenang saat tertekan"><button class="btn" style="margin-top:10px" onclick="addV()">Tambah nilai</button>`:''}
 <p class="note">Nilai adalah penilaian pribadimu, bukan ukuran ilmiah. Tidak ada skor total. Hubungkan tindakan harian ke nilai lewat kartu di Beranda.</p>`}
function addV(){const t=ask('nv1');if(!t)return;S.vals=(S.vals||[]).concat({id:Date.now(),t});save();vKompas()}
function delV(id){if(confirm('Hapus nilai ini?')){S.vals=S.vals.filter(v=>v.id!=id);save();vKompas()}}
function vReview(){const lim=Date.now()-7*864e5,E=S.entries.filter(e=>e.t>lim),F=(S.fl||[]).filter(x=>new Date(x.day+'T12:00').getTime()>lim);
 const ok=F.filter(x=>x.done).length,no=F.filter(x=>x.done===false).length;
 const en=Object.entries(S.en||{}).filter(([d])=>new Date(d+'T12:00').getTime()>lim).map(x=>x[1]);
 const avg=en.length?(en.reduce((a,b)=>a+b,0)/en.length).toFixed(1):null,L=E.filter(e=>e.b).slice(0,5);
 $('#v').innerHTML=`${back}<h1>Tinjauan mingguan</h1><p class="mut">Lima menit. Mulai dari data, bukan dari perasaan semata.</p>
 <div class="card"><h2>7 hari terakhir</h2><p>Jurnal: ${E.length}. Tindakan: ${ok} dilakukan, ${no} belum; hari tanpa catatan tidak dihitung gagal.</p><p>Energi: ${avg?'rata-rata '+avg+' dari '+en.length+' hari tercatat':'belum ada data'}.</p>${L.length?'<p class="sub">Yang kamu pelajari:</p>'+L.map(e=>`<p>• ${esc(e.b)}</p>`).join(''):''}${E.length<3?'<p class="mut">Data masih sedikit; tafsirkan dengan hati-hati.</p>':''}</div>
 <label for="r1">Apa yang berjalan?</label><textarea id="r1"></textarea>
 <label for="r2">Apa yang tidak sesuai rencana, dan mana yang di luar kendaliku?</label><textarea id="r2"></textarea>
 <label for="r3">Satu hal yang akan kuubah minggu depan</label><textarea id="r3"></textarea>
 <button class="btn" style="margin-top:10px" onclick="saveR()">Simpan tinjauan</button><div class="st" id="rs"></div>
 <h2 style="margin-top:20px">Tinjauan sebelumnya</h2><div class="card">${(S.rev||[]).map(r=>`<div class="ent"><span class="mut">${new Date(r.t).toLocaleDateString('id-ID',{dateStyle:'medium'})}</span><p><b>Ubah:</b> ${esc(r.c)}</p></div>`).join('')||'<p class="mut">Belum ada.</p>'}</div>`}
function saveR(){const a=ask('r1'),b=ask('r2'),c=ask('r3');if(!(a||b||c)){$('#rs').textContent='Isi minimal satu kolom.';return}S.rev=[{id:Date.now(),t:Date.now(),a,b,c}].concat(S.rev||[]);save();vReview()}
function vRules(){const R=S.rules||[];
 $('#v').innerHTML=`${back}<h1>Buku aturan pribadi</h1><p class="mut">Pelajaran yang sudah terbukti berguna, ditulis sebagai jika-maka. Satu aturan tampil di Beranda tiap hari.</p>
 <label for="ru1">Jika...</label><input id="ru1" placeholder="aku lelah dan menunda tugas"><label for="ru2">Maka aku akan...</label><input id="ru2" placeholder="istirahat 5 menit, lalu mulai 5 menit"><button class="btn" style="margin-top:10px" onclick="addR()">Simpan aturan</button>
 <div class="card" style="margin-top:14px">${R.map(r=>`<div class="ent"><p>Jika ${esc(r.jika)}, maka ${esc(r.maka)}.</p><button class="del" onclick="delR(${r.id})">Hapus</button></div>`).join('')||'<p class="mut">Belum ada aturan.</p>'}</div>
 <p class="note">Tulis aturan dari pengalaman yang sudah kamu uji, bukan dugaan.</p>`}
function addR(){const jika=ask('ru1'),maka=ask('ru2');if(!jika||!maka)return;S.rules=(S.rules||[]).concat({id:Date.now(),jika,maka});save();vRules()}
function delR(id){if(confirm('Hapus aturan ini?')){S.rules=S.rules.filter(r=>r.id!=id);save();vRules()}}
function vDec(){const D=S.dec||[],open=D.filter(d=>!d.hasil),done=D.filter(d=>d.hasil);
 const known=done.filter(d=>d.hasil.outcome==='ya'||d.hasil.outcome==='tidak'||typeof d.hasil.ok==='boolean');
 const cal=known.length>=5?(()=>{const y=Math.round(known.reduce((a,d)=>a+d.yakin,0)/known.length),h=Math.round(known.filter(d=>d.hasil.outcome==='ya'||d.hasil.ok===true).length/known.length*100);return `Dari ${known.length} hasil biner: rata-rata keyakinan awal ${y}%, hasil sesuai harapan ${h}%. Ini hanya ringkasan deskriptif, BUKAN bukti bahwa kamu terlalu percaya diri/ragu. Keputusan berbeda tingkat risiko, kualitas hasil tidak selalu sama dengan kualitas proses, dan sampel kecil mudah menyesatkan.`})():`Ringkasan perbandingan baru layak dibaca setelah minimal 5 hasil biner (sekarang ${known.length}). Bahkan setelah itu, angka ini bukan diagnosis kalibrasi.`;
 $('#v').innerHTML=`${back}<h1>Decision Lab</h1><p class="mut">Catat keputusan penting sebelum hasilnya diketahui. Hasil buruk tidak selalu berarti keputusan buruk; hasil baik juga tidak otomatis membuktikan prosesnya baik.</p>
 <label for="d1">Keputusan yang dipertimbangkan</label><input id="d1"><label for="d2">Pilihan alternatif</label><input id="d2"><label for="d3">Yang belum kuketahui</label><input id="d3"><label for="d4">Aku akan tinjau ulang jika...</label><input id="d4">
 <label for="d5">Seberapa yakin ini keputusan tepat? <span id="dv">70</span>%</label><input id="d5" type="range" min="50" max="95" step="5" value="70" oninput="$('#dv').textContent=this.value">
 <button class="btn" style="margin-top:10px" onclick="addD()">Simpan keputusan</button>
 <h2 style="margin-top:20px">Menunggu hasil</h2><div class="card">${open.map(d=>`<div class="ent"><b>${esc(d.m)}</b><p class="mut">Yakin ${d.yakin}%. Belum diketahui: ${esc(d.u||'—')}</p><button class="btn g" onclick="closeD(${d.id})">Catat hasil</button></div>`).join('')||'<p class="mut">Tidak ada.</p>'}</div>
 <h2 style="margin-top:16px">Selesai</h2><div class="card">${done.map(d=>`<div class="ent"><b>${esc(d.m)}</b><p class="mut">Hasil: ${esc(d.hasil.outcome||(d.hasil.ok?'sesuai harapan':'tidak sesuai harapan'))}. Kualitas proses: ${esc(d.hasil.proses||'—')}.</p><p>${esc(d.hasil.pel||'')}</p></div>`).join('')||'<p class="mut">Belum ada.</p>'}</div><p class="note">${cal}</p>`}
function addD(){const m=ask('d1');if(!m)return;S.dec=[{id:Date.now(),t:Date.now(),m,alt:ask('d2'),u:ask('d3'),tinjau:ask('d4'),yakin:+$('#d5').value,hasil:null}].concat(S.dec||[]);save();vDec()}
function closeD(id){const d=S.dec.find(x=>x.id==id);if(!d)return;const raw=prompt('Bagaimana hasilnya? Ketik: ya / tidak / belum jelas','belum jelas');if(raw===null)return;const outcome=raw.trim().toLowerCase();if(!['ya','tidak','belum jelas'].includes(outcome))return alert('Gunakan ya, tidak, atau belum jelas.');
 let p=(prompt('Kualitas proses berpikirmu saat itu: baik, cukup, atau lemah?','cukup')||'cukup').toLowerCase();if(!['baik','cukup','lemah'].includes(p))p='cukup';
 d.hasil={outcome,ok:outcome==='ya'?true:outcome==='tidak'?false:null,proses:p,pel:prompt('Pelajaran yang bisa dipakai lagi? (boleh kosong)')||''};save();vDec()}

const LN=()=>window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.LocalNotifications;
const pad2=n=>String(n).padStart(2,'0');
async function applyRem(ask){const P=LN(),r=S.rem||{on:false,h:11,m:55};
 if(!P)return 'noplugin';
 try{await P.cancel({notifications:[{id:1201}]})}catch(e){}
 if(!r.on)return 'off';
 let p=await P.checkPermissions();
 if(p.display!=='granted'){if(!ask)return 'perm';p=await P.requestPermissions();if(p.display!=='granted')return 'denied'}
 await regActs(P);await P.schedule({notifications:[{id:1201,title:'Check-in 10 detik',body:'Tindakan kecil hari ini: sudah atau belum? Ketuk untuk check-in.',actionTypeId:'CHECKIN',schedule:{on:{hour:r.h,minute:r.m},allowWhileIdle:true}}]});
 let ex='granted';try{ex=(await P.checkExactNotificationSetting()).exact_alarm}catch(e){}
 return ex==='denied'?'exact':'ok'}
function vSet(){const r=S.rem||{on:false,h:11,m:55};
 $('#v').innerHTML=`${back}<h1>Pengaturan</h1><div class="card"><h2>Pengingat harian</h2>
 <label class="sw" for="rt"><span>Aktifkan pengingat</span><input type="checkbox" id="rt" ${r.on?'checked':''} onchange="remChange()"></label>
 <label class="sw" for="rh"><span>Jam pengingat</span><input type="time" id="rh" value="${pad2(r.h)}:${pad2(r.m)}" onchange="remChange()"></label>
 <div class="st" id="rst">${LN()?'':'Pengingat hanya berfungsi di aplikasi APK. Pengaturan tetap tersimpan.'}</div>
 <div class="row" style="margin-top:10px"><button class="btn g" onclick="remTest()">Tes 5 detik</button><button class="btn g" onclick="remExact()">Izin alarm tepat waktu</button></div></div>
 <p class="note">Jam bisa diubah kapan saja, jadwal otomatis diperbarui. Jika notifikasi tidak muncul, pastikan aplikasi tidak dibatasi penghemat baterai di pengaturan HP.</p>`}
async function remChange(){const on=$('#rt').checked,[h,m]=($('#rh').value||'11:55').split(':').map(Number);S.rem={on,h,m};save();
 const st=$('#rst');st.textContent='Memproses...';let x;try{x=await applyRem(true)}catch(e){x='err'}
 st.textContent={ok:`Aktif setiap hari pukul ${pad2(h)}:${pad2(m)}.`,off:'Pengingat dimatikan.',noplugin:'Pengingat hanya berfungsi di aplikasi APK. Pengaturan tetap tersimpan.',denied:'Izin notifikasi ditolak. Aktifkan lewat pengaturan HP.',perm:'Izin notifikasi belum diberikan.',exact:`Terjadwal pukul ${pad2(h)}:${pad2(m)}, tapi izin alarm tepat waktu belum diberikan sehingga bisa terlambat. Ketuk tombol izin alarm.`,err:'Terjadi kesalahan saat menjadwalkan.'}[x]||''}
async function remTest(){const P=LN(),st=$('#rst');if(!P){st.textContent='Tes hanya di aplikasi APK.';return}
 try{const p=await P.requestPermissions();if(p.display!=='granted'){st.textContent='Izin notifikasi ditolak.';return}
 await regActs(P);await P.schedule({notifications:[{id:1202,title:'Tes Check-in',body:'Pengingat berfungsi. Coba tombol Sudah atau Belum.',actionTypeId:'CHECKIN',schedule:{at:new Date(Date.now()+5000)}}]});st.textContent='Tunggu 5 detik, tutup layar bila perlu.'}catch(e){st.textContent='Tes gagal.'}}
async function remExact(){const P=LN();if(!P)return;try{await P.changeExactNotificationSetting()}catch(e){}}

const TAGS=['tidur kurang','capek','stres','ramai','sepi','hujan','fokus','olahraga'];
let qs={done:null,en:0,tags:[]};
const regActs=P=>P.registerActionTypes({types:[{id:'CHECKIN',actions:[{id:'sudah',title:'Sudah'},{id:'belum',title:'Belum'}]}]});
function hookNotif(){const P=LN();if(!P||window._nh)return;window._nh=1;
 P.addListener('localNotificationActionPerformed',d=>{const a=d.actionId;go(0);vQuick(a==='sudah'?true:a==='belum'?false:undefined)})}
function vQuick(pre){const k=dayKey(Date.now()),f=S.focus&&S.focus.day==k?S.focus:null;
 qs={done:pre!==undefined?pre:(f&&f.done!=null?f.done:null),en:(S.en||{})[k]||0,tags:((S.tg||{})[k]||[]).slice()};drawQ()}
function drawQ(){const k=dayKey(Date.now()),f=S.focus&&S.focus.day==k?S.focus:null;
 $('#v').innerHTML=`${back}<h1>Check-in</h1>${f?`<p style="font:600 19px/1.35 Newsreader,Georgia,serif;margin:4px 0 10px">${esc(f.text)}</p><div class="row"><button class="en ${qs.done===true?'sel':''}" onclick="qSet('done',true)">Sudah</button><button class="en ${qs.done===false?'sel':''}" onclick="qSet('done',false)">Belum</button></div>`:'<p class="mut">Belum ada tindakan hari ini. Tidak apa-apa, cukup isi energi.</p>'}
 <p class="sub">Energi</p><div class="row">${[1,2,3,4,5].map(n=>`<button class="en ${qs.en==n?'sel':''}" aria-label="Energi ${n} dari 5" onclick="qSet('en',${n})">${n}</button>`).join('')}</div>
 <p class="sub">Apa yang terasa hari ini? (opsional)</p><div class="chips">${TAGS.map((t,i)=>`<button class="en tg ${qs.tags.includes(t)?'sel':''}" onclick="qTag(${i})">${t}</button>`).join('')}</div>
 <button class="btn" style="margin-top:16px;width:100%" onclick="qSave()">Simpan</button>`}
function qSet(a,v){qs[a]=v;drawQ()}
function qTag(i){const t=TAGS[i],x=qs.tags.indexOf(t);x<0?qs.tags.push(t):qs.tags.splice(x,1);drawQ()}
function qSave(){const k=dayKey(Date.now());
 if(S.focus&&S.focus.day==k&&qs.done!=null){S.focus.done=qs.done;S.fl=(S.fl||[]).filter(x=>x.day!=k);S.fl.push({day:k,text:S.focus.text,done:qs.done,v:S.focus.v})}
 if(qs.en){S.en=S.en||{};S.en[k]=qs.en}
 S.tg=S.tg||{};if(qs.tags.length)S.tg[k]=qs.tags;else delete S.tg[k];
 save();go(0)}
