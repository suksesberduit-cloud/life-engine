# The Life Intelligence Engine v1.0

**A Personal Operating System for a Meaningful Life.** PWA berbahasa Indonesia, offline-first, local-first, tanpa build step untuk menjalankan versi web. Fokusnya bukan sekadar produktivitas: memahami diri, menguji pikiran, menggunakan waktu dengan sengaja, dan mendefinisikan kecukupan.

## Modul

- **Beranda & Check-in:** satu tindakan kecil, energi 1–5, tag suasana/kondisi, pengingat lokal (APK).
- **Diary:** tiga kolom (kejadian, pelajaran, perbaikan), riwayat, pencarian, dikte.
- **Checker:** pemisahan kandidat fakta, interpretasi/asumsi, dan emosi berbasis aturan kata kunci sederhana; bukan AI atau diagnosis.
- **Eksperimen:** uji satu perubahan dengan hipotesis, ukuran, durasi, dan pengamatan.
- **Evolusi:** frekuensi jurnal dan tindakan 7 hari.
- **Life OS:** Life Balance (penilaian subjektif), Intellectual Honesty Protocol (6 tahap), Prediction Journal, Wisdom Bank, Life Timeline, Enoughness & Financial Freedom, serta backup seluruh data.
- **Alat pertumbuhan:** Kompas nilai, Tinjauan mingguan, Buku aturan pribadi, Decision Lab, dan pengingat.

## Prinsip desain

1. **Evidence-aware:** pisahkan fakta, interpretasi, asumsi, hipotesis, dan keyakinan.
2. **Anti-ilusi:** aplikasi mengundang kontra-argumen dan revisi keyakinan; tidak otomatis menyetujui pengguna.
3. **Human-first:** bukan semua hal perlu diberi skor. Hubungan, rasa syukur, kedamaian, dan kesenangan tidak direduksi menjadi KPI.
4. **Offline-first:** data disimpan di IndexedDB pada perangkat. Tidak ada akun/server/AI online pada versi ini.
5. **No financial advice:** bagian kecukupan hanya menghitung rasio dari angka yang dimasukkan pengguna; bukan rekomendasi investasi.

## Menjalankan di Android (Termux)

```bash
cd ~/storage/downloads
unzip life-engine-v1.0-github.zip -d life-engine
cd life-engine
bash setup-termux.sh
```

Buka `http://localhost:8080` di Chrome. Menu Chrome → Tambahkan ke layar utama untuk memasang PWA. Untuk fitur notifikasi terjadwal dan dikte native, gunakan APK.

## Deploy ke GitHub Pages

1. Buat repository GitHub baru dan unggah **isi folder ZIP** ke root repository (pastikan folder `.github/workflows` ikut terunggah).
2. Buka Settings → Pages → Build and deployment → Source: **GitHub Actions**.
3. Push ke `main`/`master`, atau jalankan workflow **Deploy PWA to GitHub Pages** dari tab Actions.
4. Setelah workflow sukses, buka URL Pages yang diberikan GitHub. HTTPS diperlukan untuk service worker/PWA.

## Build APK via GitHub Actions

1. Buat repository dan unggah isi ZIP termasuk `.github/workflows/build-apk.yml`, `prebuild.sh`, dan `debug.keystore`.
2. Tab **Actions** → **Build APK** → **Run workflow**. Workflow juga berjalan saat push ke `main`/`master`.
3. Setelah sukses, unduh artifact `life-engine-debug-apk`, ekstrak, lalu pasang `app-debug.apk`.

> `debug.keystore` dipertahankan agar signature debug konsisten antarrilis. Jaga file ini privat bila aplikasi berisi data sensitif. Instalasi pertama dari build yang berbeda mungkin memerlukan ekspor backup lalu uninstall versi lama.

## Backup dan pemulihan

Diary → Ekspor atau Life OS → Backup seluruh kehidupan digital membuat satu file JSON versi 2 yang mencakup seluruh state aplikasi. Impor menggabungkan jurnal berdasarkan ID dan memulihkan data modul lain dari backup. File **belum dienkripsi**: simpan di lokasi privat dan jangan unggah ke repo publik. Lakukan backup sebelum menghapus aplikasi atau membersihkan data browser.

## Batasan yang diketahui

- Life Balance adalah refleksi subjektif, bukan alat ukur psikologis.
- Checker menggunakan kata kunci lokal, bukan model AI.
- Prediction Journal mencatat prediksi dan hasil; skor kalibrasi/Brier belum dihitung otomatis.
- Belum ada enkripsi backup, PIN/biometrik, sinkronisasi cloud, AI online, atau laporan 30/90/365 hari.
- Dikte PWA Chrome dapat membutuhkan internet; APK menggunakan plugin native.
- Pengingat harian hanya tersedia di APK dan belum dapat dijamin pada semua konfigurasi Android.
- Build APK harus diverifikasi melalui GitHub Actions; belum diuji pada perangkat fisik dalam sesi ini.

## Struktur proyek

- `www/` — PWA HTML/CSS/JS, manifest, service worker, ikon.
- `android-res/` — ikon launcher Android.
- `.github/workflows/build-apk.yml` — build APK debug.
- `.github/workflows/deploy-pages.yml` — deploy PWA ke GitHub Pages.
- `setup-termux.sh` — server preview lokal.
- `prebuild.sh` — izin Android dan signing debug.
