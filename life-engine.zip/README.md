# The Life Intelligence Engine v0.1

PWA jurnal suara berbahasa Indonesia, offline-first, tanpa build step di HP.

## Isi
- android-res/ : ikon launcher Android (adaptive), disalin oleh workflow
- www/ : aplikasi (HTML, CSS, JS murni), service worker, manifest, ikon
- .github/workflows/build-apk.yml : build APK debug via GitHub Actions
- setup-termux.sh : preview lokal di Termux

## Jalankan di Termux
    cd ~/storage/downloads && unzip life-engine.zip -d life-engine && cd life-engine
    bash setup-termux.sh
Buka http://localhost:8080 di Chrome. Menu Chrome > Tambahkan ke layar utama untuk memasang PWA.

## Build APK
1. Buat repo GitHub, unggah isi folder ini (termasuk .github/workflows/build-apk.yml; jika folder tersembunyi sulit diunggah, buat file workflow manual lewat browser).
2. Tab Actions > Build APK > Run workflow.
3. Unduh artifact life-engine-debug-apk setelah hijau, ekstrak, pasang app-debug.apk.

## Status jujur
- Sudah ada: Diary 3 kolom + dikte, riwayat/cari/hapus, ekspor/impor JSON, Checker lokal (kata kunci), Kompas nilai, Tinjauan mingguan, Buku aturan jika-maka, Decision Lab, Eksperimen tunggal, tindakan harian + energi, grafik 7 hari, IndexedDB, offline.
- Belum ada: AI online, laporan bulanan/90 hari, grafik energi dan tindakan, ekspor CSV.
- Belum diuji di perangkat: seluruh build APK dan dikte native (plugin speech-recognition).
- Dikte di PWA Chrome memakai Web Speech API: butuh internet. Di APK memakai plugin native; jika gagal, pakai mikrofon papan ketik.

## Pengingat harian
Pengaturan > Pengingat harian di Beranda (Alat pertumbuhan). Toggle dan jam bisa diubah kapan saja; jadwal diperbarui otomatis. Hanya berfungsi di APK (plugin local-notifications). Belum diuji di perangkat.

## Check-in 10 detik
Beranda > Check-in cepat, atau ketuk notifikasi pengingat (tombol Sudah/Belum membuka layar check-in dengan pilihan terisi). Satu layar: Sudah/Belum, energi 1-5, tag opsional. Tombol notifikasi di Android tetap membuka aplikasi. Belum diuji di perangkat.

## Pembaruan APK
debug.keystore dipakai tetap oleh prebuild.sh agar tanda tangan APK sama di setiap build. Instal pertama setelah ini harus copot versi lama (ekspor data dulu); selanjutnya bisa ditimpa. Jangan hapus debug.keystore dari repo.
