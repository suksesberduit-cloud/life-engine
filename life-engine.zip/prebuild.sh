#!/bin/bash
# Dijalankan workflow setelah "cap sync". Tambah izin Android yang dibutuhkan.
M=android/app/src/main/AndroidManifest.xml
for p in RECORD_AUDIO POST_NOTIFICATIONS SCHEDULE_EXACT_ALARM RECEIVE_BOOT_COMPLETED; do
  grep -q "android.permission.$p" $M || sed -i "s#</manifest>#    <uses-permission android:name=\"android.permission.$p\" />\n</manifest>#" $M
done
grep -c uses-permission $M
