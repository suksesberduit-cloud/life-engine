#!/data/data/com.termux/files/usr/bin/bash
# Jalankan: bash setup-termux.sh
pkg install -y python git unzip >/dev/null
echo "Preview lokal: http://localhost:8080  (Ctrl+C untuk berhenti)"
cd "$(dirname "$0")/www" && python -m http.server 8080
